import { useEffect, useState } from "react";

type FsDoc = Document & { webkitFullscreenElement?: Element; webkitExitFullscreen?: () => Promise<void> };
type FsEl = HTMLElement & { webkitRequestFullscreen?: () => Promise<void> };

const fsEl = () => { const d = document as FsDoc; return d.fullscreenElement || d.webkitFullscreenElement || null; };

/** 전체화면 토글. iOS Safari 등 미지원 환경에선 조용히 무시됩니다. */
export function FullscreenToggle({ className = "btn" }: { className?: string }) {
  const [fs, setFs] = useState(false);
  useEffect(() => {
    const on = () => setFs(!!fsEl());
    document.addEventListener("fullscreenchange", on);
    document.addEventListener("webkitfullscreenchange", on);
    on();
    return () => {
      document.removeEventListener("fullscreenchange", on);
      document.removeEventListener("webkitfullscreenchange", on);
    };
  }, []);
  const toggle = async () => {
    try {
      const d = document as FsDoc;
      if (!fsEl()) {
        const el = document.documentElement as FsEl;
        await (el.requestFullscreen?.() ?? el.webkitRequestFullscreen?.());
      } else {
        await (d.exitFullscreen?.() ?? d.webkitExitFullscreen?.());
      }
    } catch {
      /* 전체화면 미지원/차단 환경 */
    }
  };
  return (
    <button className={className} aria-pressed={fs} onClick={toggle} title="전체화면 전환">
      {fs ? "전체화면 해제" : "전체화면"}
    </button>
  );
}
